﻿

namespace Interfaces_and_Abstraction___Military_Elite.Models.Interfaces
{
    public interface ISoldier
    {
        public int ID { get; }
        public string FirstName { get; }
        public string LastName { get; }
    }
}
