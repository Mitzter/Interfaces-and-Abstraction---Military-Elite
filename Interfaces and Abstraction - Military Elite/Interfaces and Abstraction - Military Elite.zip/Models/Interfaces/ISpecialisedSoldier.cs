﻿

namespace Interfaces_and_Abstraction___Military_Elite.Models.Interfaces
{
    public interface ISpecialisedSoldier : IPrivate
    {
        public string Corps { get; set; }
    }
}
