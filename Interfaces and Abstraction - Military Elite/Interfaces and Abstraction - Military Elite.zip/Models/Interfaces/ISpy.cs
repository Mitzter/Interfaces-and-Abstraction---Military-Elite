﻿

namespace Interfaces_and_Abstraction___Military_Elite.Models.Interfaces
{
    public interface ISpy : ISoldier
    {
        public int CodeNumber { get; set; }
    }
}
